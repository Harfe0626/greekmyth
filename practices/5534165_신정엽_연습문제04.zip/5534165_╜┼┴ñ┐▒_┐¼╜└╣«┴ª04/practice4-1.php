<?php
    $num = 1;   //$num

    while ($num<=1000)
    {
        if($num%2 == 0)  //$num%2
        echo "$num ";

        $num++;  //$num++
    }
?>