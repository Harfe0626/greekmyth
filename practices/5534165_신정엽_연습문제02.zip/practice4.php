<?php 
//Q. 자신의 이름, 휴대폰 번호, 주소, 이메일 주소를 출력하는 프로그램을 작성하시오.

//A.
    echo "Q4. 자신의 이름, 휴대폰 번호, 주소, 이메일 주소를 출력하는 프로그램을 작성하시오.<br>";
	$name = "신정엽";
	$address = "대구 달서구 월서로";
	$phone = "010-7127-1089";
	$email = "strik241@gmail.com";

	echo "- 이름 : $name<br>";
	echo "- 휴대폰 번호 : $phone<br>";
	echo "- 주소 : $address<br>";
	echo "- 이메일 : $email<br>";
?>