<?php 
//Q. 다음 중 PHP의 변수명으로 옳지 않은 것은?

/*
A. -2번- $my age
*/
echo "Q3. 다음 중 PHP의 변수명으로 옳지 않은 것은?<br>";
echo "2번 $ my age";
?>