<?php 
//Q. 다음은 공원 입장료를 계산하는 프로그램이다. 빈칸을 채워 프로그램을 완성하시오.

//A. 
echo "Q13. 다음은 공원 입장료를 계산하는 프로그램이다. 빈칸을 채워 프로그램을 완성하시오.<br>";
$child_fee = 5000;
$adult_fee = 8000;
$num_child = 3;
$num_adult = 2;

$total_fee = $child_fee * $num_child + $adult_fee * $num_adult; // $child_fee, $adult_fee, $num_adult

echo "전체 입장료 : $total_fee 원"; // $total_fee
?>