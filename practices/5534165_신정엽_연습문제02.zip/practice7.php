<?php 
/*Q. 변수 $name을 출력하는 <?php echo $name?>의 약식 표현은 무엇인가?*/

//A. -1번- 
echo "Q7. 변수 $ name을 출력하는 <?php echo $ name?>의 약식 표현은 무엇인가?<br>";
echo "1번"; /*<?=$name?>*/
?>